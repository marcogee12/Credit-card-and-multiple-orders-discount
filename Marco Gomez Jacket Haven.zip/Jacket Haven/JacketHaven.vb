﻿'Name: Jacket Haven'
'Purpose: Calculate total amount of jackets ordered. Calculate discount with credit card. Calculate discount for purchase of 2 or more with out credit card.'
'Programmer: Marco Gomez'
'Date: 6/19/2019'
Public Class Form1

    'Calculates total amount of jackets ordered. Calculates discount with credit card. Calculates discount for purchase of 2 or more with out credit card.'
    Private Sub BtnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        'Variable scope for input of the amount of jackets ordered times their prices'
        Dim BlackTotal As Double = txtBlack.Text * 45.99
        Dim NavyTotal As Double = txtNavy.Text * 39.99
        Dim RedTotal As Double = txtRed.Text * 39.99

        'Sets variable for Total amount of jackets ordered'
        Dim TotalOrdered As Double = Convert.ToDouble(txtBlack.Text) + Convert.ToDouble(txtNavy.Text) + Convert.ToDouble(txtRed.Text)

        'Sets variable for total price of the jackets ordered'
        Dim TotalDue As Double = BlackTotal + NavyTotal + RedTotal

        'Verifies whether credit card is being used and if more than 2 items are being ordered than calculates discount accordingly.'
        If chkCredit.Checked Then
            TotalDue = TotalDue * 0.9
        ElseIf TotalOrdered >= 2 And chkCredit.CheckState = False Then
            TotalDue = TotalDue * 0.95
        End If

        'Displays the total amount of jackets ordered.'
        txtTotalOrder.Text = Convert.ToString(TotalOrdered)

        'Displays the total amount due for the jackets ordered as a currency after calculating discounts according to conditions'
        txtTotalDue.Text = FormatCurrency(TotalDue)
    End Sub

    'Send exit button the evet to close te app'
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
